using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;

public class showScore : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        TextMeshProUGUI s;
        if (GameObject.Find("Score").GetComponent<TextMeshProUGUI>())
        {
            s = GameObject.Find("Score").GetComponent<TextMeshProUGUI>();

            float score = GameManager.distance + 50 * GameManager.coinsnum;
            s.text = "  Score: \n  " + (int)score;
            if(score > GameManager.HighestScore) PlayerPrefs.SetFloat("HighestScore", score);
        }
    }
}
