using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class restart : MonoBehaviour
{
    // Start is called before the first frame update
    public void OnLoginButtonClick()
    {
        PlayerMove.forwardSpeed = 20f;
        SceneManager.LoadScene(1);
        GameManager.coinsnum = 0;
        
    }
}
