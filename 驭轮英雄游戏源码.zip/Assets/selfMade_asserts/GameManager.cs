using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.UIElements;
using Unity.Collections.LowLevel.Unsafe;
using System.Runtime.InteropServices;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    //���ö�����Ѫ��
    public byte life = 7; 
   
    public static int coinsnum;
    public static float distance =0;
    public static float HighestScore = -1;
    public GameObject hp1;
    public GameObject hp2 ;
    public GameObject hp3 ;
    public GameObject player;
    public MusicManager musicmanager;
    private void Awake()
    {
        if(PlayerPrefs.HasKey("HighestScore"))
        {
            HighestScore = PlayerPrefs.GetFloat("HighestScore");
        }
       PlayerPrefs.SetFloat("HighestScore", HighestScore);
    }

    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        distance = player.transform.position.z +30;
        //if(distance>farthest)
        //{
        //    farthest = distance;
        //    PlayerPrefs.SetFloat("FarthestDistance", farthest);
        //}
        TextMeshProUGUI Coins;
        TextMeshProUGUI Distance;
        TextMeshProUGUI HiS;
        Coins = GameObject.Find("CoinsNum").GetComponent<TextMeshProUGUI>();
        Distance = GameObject.Find("Distance").GetComponent<TextMeshProUGUI>();
        HiS = GameObject.Find("HighestScore").GetComponent<TextMeshProUGUI>();
        Coins.text = "Coins: " + coinsnum;
        Distance.text = "Distance: " + distance.ToString("0");
        HiS.text = "HighestScore: " + HighestScore.ToString("0");
        TextMeshProUGUI Speed;
        Speed = GameObject.Find("Speed").GetComponent<TextMeshProUGUI>();
        Speed.text = "Speed:"+ (PlayerMove.forwardSpeed).ToString("0");
        hp1.SetActive((life & 0b0100) != 0);
        
        hp2.SetActive((life & 0b0010) != 0);
        
        hp3.SetActive((life & 0b0001) != 0);
      

    }
    public void AddCoins()
    {
        coinsnum++;
        if(coinsnum%20==0)
        {
            byte pastlife = life;
            for(int i=2;i>=0;--i)
            {
                if (((life >> i) & 1) == 0)
                {
                    life |=(byte) ((1 << i));
                    if(life!=pastlife)
                    {
                        musicmanager.addBlood();
                    }
                    return;
                }
            }
        }
    }
    public void GetHurt()
    {
        if (life>0 && !PlayerMove.shieldActive)
        {
           for(int i=0;i<=2;++i)
            {
                if(((life>>i)&1)==1)
                {
                    life &= (byte)~(1 << i);
                    musicmanager.decBlood();
                    break;
                }
            }
        }
        if(life==0)
        {

       
            Debug.Log("Game Over");
            SceneManager.LoadScene("EndScene");
            PlayerMove.forwardSpeed = 20f;
            GameManager.coinsnum = 0;
            
        }
    }
}
