
using System;
using System.Collections;
using UnityEditor;


using UnityEngine;
using UnityEngine.UIElements;
using Random = UnityEngine.Random;
using System.Collections.Generic;

#if UNITY_EDITOR
using UnityEditor.Timeline;
using UnityEditor.UIElements;
#endif
public class RoadManager : MonoBehaviour
{
    

    // ��·�б�
    public List<Transform> roadList = new List<Transform>();
    // �ִ���б�
    public List<Transform> arrivePosList = new List<Transform>();
    // �ϰ����б�
    public List<GameObject> objPrefabList = new List<GameObject>();
    // Ŀǰ���ϰ���
    Dictionary<string, List<GameObject>> objDict = new Dictionary<string, List<GameObject>>();
    public List<GameObject> BenifitsList = new List<GameObject>();
    // ��·�������
    public int roadDistance = 60;
  
    public float BarrelBornPercent = 0.2f;
    public int maxObstacles = 10;
    public int Coinslistnum = 2;
    public int Benifitnum = 5;
    public float BenifitBornPercent = 0.2f;
   
    // Start is called before the first frame update
    void Start()
    {
        foreach (Transform road in roadList)
        {
            List<GameObject> objList = new List<GameObject>();
            objDict.Add(road.name, objList);
            Debug.Log("Added road " + road.name + " to objDict.");
        }
        initRoad(1);
        initRoad(2);
    }

    // Update is called once per frame
    void Update()
    {
        BarrelBornPercent = 0.2f+GameManager.distance / 100000;
        if(BenifitBornPercent>0.1f)
        BenifitBornPercent = 0.2f - GameManager.distance / 100000;
        
    }

    // �г��µĵ�·
    public void ChangeRoad(Transform arrivePos)
    {
        int index = arrivePosList.IndexOf(arrivePos);
        if (index >= 0)
        {
            int lastIndex = index - 1;
            if (lastIndex < 0)
                lastIndex = roadList.Count - 1;
            // �ƶ���·
            roadList[index].position = roadList[lastIndex].position + new Vector3(0, 0, roadDistance);

            initRoad(index);
        }
        else
        {
            Debug.LogError("arrivePos index is error");
            return;
        }
    }

    void initRoad(int index)
    {

        string roadName = roadList[index].name;

        // ��������ϰ���
        foreach (GameObject obj in objDict[roadName])
        {
            Destroy(obj);
        }
        objDict[roadName].Clear();

  
        // ����������ɵ��ϰ���
        for (int i = 0; i < maxObstacles; i++)
        {
            if (Random.value <= BarrelBornPercent)
            {
              
                GameObject prefab = objPrefabList[Random.Range(0, objPrefabList.Count)];
                Vector3 randomPosition = new Vector3(
                    Random.Range(-5, 5),
                    2,  // assuming y is constant for simplicity
                    Random.Range(roadList[index].position.z - 30, roadList[index].position.z + 30));
              
                Vector3 eulerAngle = new Vector3(0, Random.Range(0, 360), 0);
                GameObject obj = Instantiate(prefab, randomPosition, Quaternion.Euler(eulerAngle)) as GameObject;
              
                obj.layer = 7;
           
                objDict[roadName].Add(obj);
                
            }
        }
       for(int i=0;i<Coinslistnum;i++)
        {
            GameObject prefab = BenifitsList[0];
            Vector3 randomPosition = new Vector3(
                    Random.Range(-5, 5),
                    2,  // assuming y is constant for simplicity
                    Random.Range(roadList[index].position.z - 30, roadList[index].position.z + 30));
            for (int j = 0; j < 5; j++)
            {
                GameObject obj = Instantiate(prefab, randomPosition+new Vector3(0,0,j*4), Quaternion.Euler(0, 0, 0)) as GameObject;
                obj.tag = "Coins";
                obj.layer = 8;
                objDict[roadName].Add(obj);
            }
        }
    for(int i=0;i<Benifitnum;i++)
        {
            if(Random.value < BenifitBornPercent)
            {
                GameObject benifit = BenifitsList[Random.Range(1, BenifitsList.Count)];
                Vector3 randomPosition = new Vector3(
                    Random.Range(-4, 4),
                    2,  // assuming y is constant for simplicity
                    Random.Range(roadList[index].position.z - 30, roadList[index].position.z + 30));

                if (benifit.tag.Equals("speed_up"))
                {
                    
                    randomPosition.x = Random.Range(-0.3f, 5f);
                    randomPosition.y = 0.9f;
                }
                GameObject obj = Instantiate(benifit, randomPosition, Quaternion.Euler(0, 0, 0)) as GameObject;
              
                obj.layer = 8;
                objDict[roadName].Add(obj);
            }
        }
    }

}
