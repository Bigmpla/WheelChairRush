using UnityEngine;
using System.Collections;
using System;

public class PlayerMove : MonoBehaviour
{
    // Player movement settings
    public static float forwardSpeed = 20f;  // Speed at which the player moves forward
    public float strafeSpeed = 10f;    // Speed at which the player moves left/right
    public float rotationSpeed = 5f;  // Speed at which the player rotates
    public float limit_LR = 5f;       // Limit for left/right movement

    // Camera settings
    private Vector3 cameraOffset;
    public RoadManager roadManager;
    public GameManager gameManager;
    public MusicManager musicManager;
    public GameObject ExchangeImage;
    // Speed up settings
    public float speedUpAmount = 3f;    // The amount to increase the speed by
    public float speedUpDuration = 2f;  // The duration of the speed up in seconds
    public float slowDownDuration = 5f; // The duration to slow down to original speed

    private float initialForwardSpeed;
    private float currentSpeedBonus = 0f;
    private Coroutine slowDownCoroutine;

    public GameObject shieldPrefab;
    public float shieldDuration = 5f; // �����ֳ���ʱ��
    public static bool shieldActive = false; // �������Ƿ񼤻�
    private GameObject shieldInstance; // ������ʵ��

    private int LeftAndRightExchgange = 1;
    private Coroutine exchangeCoroutine; // ���������ƶ������Э��
    // Start is called before the first frame update
    void Start()
    {
        // Initialize the camera offset
        cameraOffset = Camera.main.transform.position - transform.position;
        initialForwardSpeed = 20f;
    }

    // Update is called once per frame
    void Update()
    {
        // Update camera position
        Camera.main.transform.position = transform.position + cameraOffset;
        // Handle player movement
        HandleMovement();
        ExchangeImage.SetActive(LeftAndRightExchgange==-1);
    }

    void HandleMovement()
    {
        // Get input for lateral movement
        float moveLR = Input.GetAxis("Horizontal") * LeftAndRightExchgange;

        // Calculate forward movement
        Vector3 forwardMovement = transform.forward * forwardSpeed * Time.deltaTime;

        // Calculate lateral movement
        Vector3 lateralMovement = transform.right * moveLR * strafeSpeed * Time.deltaTime;

        // Combine movements
        Vector3 movement = forwardMovement + lateralMovement;
        if (transform.position.x + movement.x > limit_LR)
        {
            movement.x = limit_LR - transform.position.x;
        }
        if (transform.position.x + movement.x < -limit_LR)
        {
            movement.x = -limit_LR - transform.position.x;
        }
        // Apply movement
        transform.Translate(movement, Space.World);

        // Handle rotation
        if (moveLR != 0)
        {
            // Calculate target rotation based on lateral movement
            float targetAngle = Mathf.Atan2(moveLR, 1f) * Mathf.Rad2Deg;
            Quaternion targetRotation = Quaternion.Euler(0, targetAngle, 0);

            // Smoothly rotate towards the target rotation
            transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, rotationSpeed * Time.deltaTime);
        }
    }

    void OnTriggerEnter(Collider other)
    {
        // ����ǵִ��
        if (other.name.Equals("ArrivePos"))
        {
            roadManager.ChangeRoad(other.transform);
        }
        // ������ϰ���
        else if (other.gameObject.tag.Equals("Obstacle"))
        {
            gameManager.GetHurt();
            Destroy(other.gameObject);
            if (slowDownCoroutine != null)
            {
                StopCoroutine(slowDownCoroutine);
            }
            slowDownCoroutine = StartCoroutine(Slow_down());
        }
        else if(other.gameObject.tag.Equals("Banana"))
        {
            if(!shieldActive)
            LeftAndRightExchgange = -1;
            musicManager.MeetBanana();
            if (exchangeCoroutine != null)
            {
                StopCoroutine(exchangeCoroutine);
            }
            exchangeCoroutine = StartCoroutine(ExchangeLR());
            Destroy(other.gameObject);
        }
        else if (other.tag.Equals("Coins"))
        {
            gameManager.AddCoins();
            musicManager.AddCoins();
            Destroy(other.gameObject);
        }
        else if (other.tag.Equals("speed_up"))
        {
            //if (slowDownCoroutine != null)
            //{
            //    StopCoroutine(slowDownCoroutine);
            //}
            if (forwardSpeed < 50)
            {
                currentSpeedBonus += speedUpAmount;
                forwardSpeed = initialForwardSpeed + currentSpeedBonus;
            }
            //slowDownCoroutine = StartCoroutine(Slow_down());
        }
        else if(other.tag.Equals("protect"))
        {
            // ���ɷ�����
            ActivateShield();
            Destroy(other.gameObject);
            
        }
    }

    IEnumerator Slow_down()
    {
        float elapsed = 0f;
        float startSpeedBonus = currentSpeedBonus;

        while (elapsed < slowDownDuration)
        {
            currentSpeedBonus = Mathf.Lerp(startSpeedBonus, Math.Max(startSpeedBonus - 10,0), elapsed / slowDownDuration);
            forwardSpeed = initialForwardSpeed + currentSpeedBonus;
            elapsed += Time.deltaTime;
            yield return null;
        }

        //currentSpeedBonus = 0f;
        //forwardSpeed = initialForwardSpeed;
    }

        void ActivateShield()
        {
            if (!shieldActive)
            {
                // �������Χ���ɷ�����
                shieldInstance = Instantiate(shieldPrefab, transform.position+new Vector3(0,0.6f,0), transform.rotation);
                shieldInstance.transform.parent = transform;
                shieldActive = true;

                StartCoroutine(DeactivateShield());
            }
        }
    IEnumerator DeactivateShield()
    {
        // �ȴ������ֳ���ʱ��
        yield return new WaitForSeconds(shieldDuration);
        // ���ٷ�����
        Destroy(shieldInstance);
        shieldActive = false;
    }

    IEnumerator ExchangeLR()
    {

        float elapsed = 0f;
        float effectDuration = 5.0f; // ����Ч��ʱ��

        while (elapsed < effectDuration)
        {
            elapsed += Time.deltaTime;
            yield return null;
        }

        LeftAndRightExchgange = 1;
    }
}



