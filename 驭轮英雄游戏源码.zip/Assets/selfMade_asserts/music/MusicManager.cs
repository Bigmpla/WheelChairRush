using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class MusicManager : MonoBehaviour
{
    public Slider MusicSilder;
    public Toggle MusicToggle;
    public AudioSource BackgroundMusic;
    public AudioSource CoinMusic;
    public AudioSource ShieldMeetObstacle;
    public AudioSource AddBlood;
    public AudioSource DecBlood;
    public AudioSource BananaAS;
    // Start is called before the first frame update
    void Start()
    {
        BackgroundMusic.volume = 0.1f;
    }

    // Update is called once per frame
    void Update()
    {

    }
    public void BGMShow()
    {
        BackgroundMusic.mute = !MusicToggle.isOn;
        BackgroundMusic.volume = MusicSilder.value;
    }
    public void AddCoins()
    {
      AudioSource.PlayClipAtPoint(CoinMusic.clip, Camera.main.transform.position);
    }
    public void ProtectBallhurt()
    {
           AudioSource.PlayClipAtPoint(ShieldMeetObstacle.clip, Camera.main.transform.position);
    }
    public void addBlood()
    {
        AudioSource.PlayClipAtPoint(AddBlood.clip, Camera.main.transform.position);
    }
    public void decBlood()
    {
        AudioSource.PlayClipAtPoint(DecBlood.clip, Camera.main.transform.position);
    }
    public void MeetBanana()
    {
        AudioSource.PlayClipAtPoint(BananaAS.clip, Camera.main.transform.position);
    }
}
