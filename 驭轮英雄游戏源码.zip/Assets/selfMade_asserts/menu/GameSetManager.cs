using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameSetManager : MonoBehaviour
{
   
    public GameObject GameSetPannel;
    // Start is called before the first frame update
    void Start()
    {
        GameSetPannel.SetActive(false);
        Time.timeScale = 1;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void BackToHome()
    {
        
        SceneManager.LoadScene("BeginScene");
    }
    public void Restart()
    {
        SceneManager.LoadScene("GameScene");
    }
    public void StopGame()
    {
        GameSetPannel.SetActive(true);
        Time.timeScale = 0;
    }
    public void Continue()
    {
        GameSetPannel.SetActive(false);
        Time.timeScale = 1;
    }
    
}
